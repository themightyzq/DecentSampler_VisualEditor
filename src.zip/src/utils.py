global_style = """
QWidget { font-family: Sans-Serif; font-size: 11pt; }
QDockWidget { titlebar-close-icon: url(); titlebar-normal-icon: url(); }
"""
