from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QListWidget, QPushButton, QFileDialog, QHBoxLayout
from PyQt5.QtCore import Qt
from commands.commands import SampleAutoMapCommand

class SamplePanel(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main_window = main_window
        self.samples = []
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Samples"))
        self.list_widget = QListWidget()
        self.list_widget.setToolTip("List of imported samples")
        layout.addWidget(self.list_widget)

        # Keyzone mapping controls
        from PyQt5.QtWidgets import QFormLayout, QSpinBox, QGroupBox
        self.zone_group = QGroupBox("Keyzone Mapping")
        self.zone_group.setToolTip("Set the keyzone for the selected sample")
        zone_layout = QFormLayout()
        self.lo_spin = QSpinBox()
        self.lo_spin.setRange(0, 127)
        self.lo_spin.setToolTip("Low MIDI note (0–127)")
        zone_layout.addRow("Low Note", self.lo_spin)
        self.hi_spin = QSpinBox()
        self.hi_spin.setRange(0, 127)
        self.hi_spin.setToolTip("High MIDI note (0–127)")
        zone_layout.addRow("High Note", self.hi_spin)
        self.root_spin = QSpinBox()
        self.root_spin.setRange(0, 127)
        self.root_spin.setToolTip("Root MIDI note (0–127)")
        zone_layout.addRow("Root Note", self.root_spin)
        # Add "Change Sample File" button
        from PyQt5.QtWidgets import QPushButton
        self.change_sample_btn = QPushButton("Change Sample File")
        self.change_sample_btn.setToolTip("Select WAV file for this mapping")
        self.change_sample_btn.clicked.connect(self._on_change_sample_file)
        zone_layout.addRow(self.change_sample_btn)
        self.zone_group.setLayout(zone_layout)
        layout.addWidget(self.zone_group)

        btn_layout = QHBoxLayout()
        import_btn = QPushButton("Import Samples")
        import_btn.clicked.connect(self.import_samples)
        btn_layout.addWidget(import_btn)
        auto_map_btn = QPushButton("Auto-Map Folder…")
        auto_map_btn.clicked.connect(self.auto_map_folder)
        btn_layout.addWidget(auto_map_btn)
        layout.addLayout(btn_layout)
        self.setLayout(layout)

        self.list_widget.currentItemChanged.connect(self.on_sample_selected)
        self.lo_spin.valueChanged.connect(self._on_spin_changed)
        self.hi_spin.valueChanged.connect(self._on_spin_changed)
        self.root_spin.valueChanged.connect(self._on_spin_changed)

    def set_samples(self, samples):
        """samples: list of SampleMapping or dicts with path, lo, hi, root"""
        self.samples = samples
        self.list_widget.clear()
        for m in samples:
            # m can be a SampleMapping or dict
            path = getattr(m, "path", m.get("path", "")) if hasattr(m, "path") or isinstance(m, dict) else str(m)
            lo = getattr(m, "lo", m.get("lo", 0)) if hasattr(m, "lo") or isinstance(m, dict) else 0
            hi = getattr(m, "hi", m.get("hi", 0)) if hasattr(m, "hi") or isinstance(m, dict) else 0
            root = getattr(m, "root", m.get("root", 0)) if hasattr(m, "root") or isinstance(m, dict) else 0
            display = f"{self.midi_note_name(lo)} ({lo}) – {self.midi_note_name(hi)} ({hi}), root {self.midi_note_name(root)} ({root})"
            item_text = f"{display}\n{path}"
            self.list_widget.addItem(item_text)
            item = self.list_widget.item(self.list_widget.count() - 1)
            item.setToolTip(f"Sample: {path}\nLow MIDI note: {self.midi_note_name(lo)} ({lo})\nHigh MIDI note: {self.midi_note_name(hi)} ({hi})\nRoot note: {self.midi_note_name(root)} ({root})")
        # After setting samples, clear spin boxes
        self.lo_spin.setValue(0)
        self.hi_spin.setValue(0)
        self.root_spin.setValue(0)
        self.zone_group.setEnabled(False)

    @staticmethod
    def midi_note_name(n):
        names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        octave = (n // 12) - 1
        note = names[n % 12]
        return f"{note}{octave}"

    def import_samples(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Import WAV Samples", "", "WAV Files (*.wav)")
        if files:
            # Add as dicts with default mapping
            for f in files:
                self.samples.append({"path": f, "lo": 0, "hi": 127, "root": 60})
            self.set_samples(self.samples)
            # TODO: Push undo command and update preset/mapping form

    def auto_map_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Sample Folder")
        if folder and hasattr(self.main_window, "preset"):
            old_mappings = list(self.main_window.preset.mappings)
            self.main_window.preset.auto_map(folder)
            new_mappings = list(self.main_window.preset.mappings)
            cmd = SampleAutoMapCommand(
                self.main_window.preset, old_mappings, new_mappings, update_callback=self.refresh_sample_list
            )
            if hasattr(self.main_window, "undo_stack"):
                self.main_window.undo_stack.push(cmd)
            else:
                self.refresh_sample_list()

    def refresh_sample_list(self):
        if hasattr(self.main_window, "preset"):
            self.set_samples([m.path for m in self.main_window.preset.mappings])

    def on_sample_selected(self, curr, prev):
        if curr:
            idx = self.list_widget.row(curr)
            mapping = self.samples[idx]
            self.lo_spin.blockSignals(True)
            self.hi_spin.blockSignals(True)
            self.root_spin.blockSignals(True)
            self.lo_spin.setValue(mapping.get("lo", 0))
            self.hi_spin.setValue(mapping.get("hi", 127))
            self.root_spin.setValue(mapping.get("root", 60))
            self.lo_spin.blockSignals(False)
            self.hi_spin.blockSignals(False)
            self.root_spin.blockSignals(False)
            self.zone_group.setEnabled(True)
        else:
            self.zone_group.setEnabled(False)

    def _on_spin_changed(self):
        curr = self.list_widget.currentItem()
        if curr:
            idx = self.list_widget.row(curr)
            mapping = self.samples[idx]
            mapping["lo"] = self.lo_spin.value()
            mapping["hi"] = self.hi_spin.value()
            mapping["root"] = self.root_spin.value()
            # Update list item text and tooltip
            display = f"{self.midi_note_name(mapping['lo'])} ({mapping['lo']}) – {self.midi_note_name(mapping['hi'])} ({mapping['hi']}), root {self.midi_note_name(mapping['root'])} ({mapping['root']})"
            item_text = f"{display}\n{mapping['path']}"
            curr.setText(item_text)
            curr.setToolTip(f"Sample: {mapping['path']}\nLow MIDI note: {self.midi_note_name(mapping['lo'])} ({mapping['lo']})\nHigh MIDI note: {self.midi_note_name(mapping['hi'])} ({mapping['hi']})\nRoot note: {self.midi_note_name(mapping['root'])} ({mapping['root']})")
            # Live update preview
            if hasattr(self.main_window, "preview_canvas") and hasattr(self.main_window, "preset"):
                self.main_window.preview_canvas.set_preset(self.main_window.preset, "")

    def _on_change_sample_file(self):
        from PyQt5.QtWidgets import QFileDialog
        curr = self.list_widget.currentItem()
        if curr:
            idx = self.list_widget.row(curr)
            mapping = self.samples[idx]
            file, _ = QFileDialog.getOpenFileName(self, "Select WAV File", "", "WAV Files (*.wav)")
            if file:
                mapping["path"] = file
                # Update list item text and tooltip
                display = f"{self.midi_note_name(mapping['lo'])} ({mapping['lo']}) – {self.midi_note_name(mapping['hi'])} ({mapping['hi']}), root {self.midi_note_name(mapping['root'])} ({mapping['root']})"
                item_text = f"{display}\n{mapping['path']}"
                curr.setText(item_text)
                curr.setToolTip(f"Sample: {mapping['path']}\nLow MIDI note: {self.midi_note_name(mapping['lo'])} ({mapping['lo']})\nHigh MIDI note: {self.midi_note_name(mapping['hi'])} ({mapping['hi']})\nRoot note: {self.midi_note_name(mapping['root'])} ({mapping['root']})")
                # Live update preview
                if hasattr(self.main_window, "preview_canvas") and hasattr(self.main_window, "preset"):
                    self.main_window.preview_canvas.set_preset(self.main_window.preset, "")
