from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel
from PyQt5.QtGui import QPainter, QColor, QPen, QBrush, QPixmap
from PyQt5.QtCore import Qt, QRect

class PreviewCanvas(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.preset = None
        self.base_dir = ""
        self.bg_pixmap = None
        self.setMinimumHeight(180)
        self.setToolTip("Preview of sample mappings and UI background")

    def set_preset(self, preset, base_dir):
        self.preset = preset
        self.base_dir = base_dir
        self.bg_pixmap = None
        if preset and getattr(preset, "bg_image", None):
            import os
            img_path = preset.bg_image
            if not os.path.isabs(img_path):
                img_path = os.path.join(base_dir, img_path)
            self.bg_pixmap = QPixmap(img_path)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        w, h = self.width(), self.height()
        # Draw background image if available
        if self.bg_pixmap and not self.bg_pixmap.isNull():
            painter.drawPixmap(self.rect(), self.bg_pixmap)
        else:
            painter.fillRect(self.rect(), QColor("#f0f0f0"))

        # Draw preset name
        if self.preset:
            painter.setPen(Qt.black)
            painter.setFont(self.font())
            painter.drawText(10, 20, f"Preset: {self.preset.name}")

        # Draw piano keyboard
        kb_y = h - 60
        kb_h = 50
        kb_x = 10
        kb_w = w - 20
        n_keys = 128
        key_w = kb_w / n_keys
        # Draw white keys
        for i in range(n_keys):
            x = kb_x + i * key_w
            is_black = self.is_black_key(i)
            if not is_black:
                painter.setBrush(QBrush(Qt.white))
                painter.setPen(QPen(Qt.black))
                painter.drawRect(QRect(int(x), kb_y, int(key_w), kb_h))
        # Draw black keys
        for i in range(n_keys):
            x = kb_x + i * key_w
            if self.is_black_key(i):
                painter.setBrush(QBrush(Qt.black))
                painter.setPen(QPen(Qt.black))
                painter.drawRect(QRect(int(x + key_w * 0.6), kb_y, int(key_w * 0.8), int(kb_h * 0.6)))
        # Highlight sample mappings
        if self.preset:
            for m in getattr(self.preset, "mappings", []):
                lo, hi, root = m.lo, m.hi, m.root
                # Highlight range
                painter.setBrush(QBrush(QColor(100, 200, 255, 120)))
                painter.setPen(Qt.NoPen)
                x1 = kb_x + lo * key_w
                x2 = kb_x + (hi + 1) * key_w
                painter.drawRect(QRect(int(x1), kb_y, int(x2 - x1), kb_h))
                # Draw root note
                painter.setBrush(QBrush(QColor(255, 100, 100, 180)))
                painter.setPen(Qt.NoPen)
                rx = kb_x + root * key_w
                painter.drawRect(QRect(int(rx), kb_y, int(key_w), kb_h))

    @staticmethod
    def is_black_key(n):
        return n % 12 in [1, 3, 6, 8, 10]
