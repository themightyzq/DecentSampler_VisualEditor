from PyQt5.QtWidgets import (
    QMainWindow, QAction, QFileDialog, QMessageBox, QSplitter, QWidget, QVBoxLayout, QApplication
)
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QUndoStack
from views.panels.sample_browser import SamplePanel
from views.forms.mapping_form import MappingForm
from views.panels.global_options_panel import GlobalOptionsPanel
from panels.project_properties import ProjectPropertiesPanel
from views.panels.preview_canvas import PreviewCanvas
from model import InstrumentPreset
import controller
import os

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DecentSampler Form Editor")
        self.setGeometry(100, 100, 900, 600)
        self.undo_stack = QUndoStack(self)
        self.preset = None

        self._create_menu()
        self._create_central()
        self._createGlobalOptionsPanel()
        self._connectSignals()
        self.new_preset()  # Always start with a blank preset

    def _create_menu(self):
        menubar = self.menuBar()
        file_menu = menubar.addMenu("File")
        new_action = QAction("New", self)
        new_action.triggered.connect(self.new_preset)
        file_menu.addAction(new_action)
        open_action = QAction("Open...", self)
        open_action.triggered.connect(self.open_preset)
        file_menu.addAction(open_action)
        save_action = QAction("Save", self)
        save_action.triggered.connect(self.save_preset)
        file_menu.addAction(save_action)
        file_menu.addSeparator()
        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)

        edit_menu = menubar.addMenu("Edit")
        undo_action = self.undo_stack.createUndoAction(self, "Undo")
        undo_action.setShortcut("Ctrl+Z")
        redo_action = self.undo_stack.createRedoAction(self, "Redo")
        redo_action.setShortcut("Ctrl+Y")
        edit_menu.addAction(undo_action)
        edit_menu.addAction(redo_action)

    def _create_central(self):
        splitter = QSplitter(Qt.Horizontal)
        self.sample_panel = SamplePanel(self)
        self.mapping_form = MappingForm(self)
        self.preview_canvas = PreviewCanvas(self)
        splitter.addWidget(self.sample_panel)
        splitter.addWidget(self.mapping_form)
        splitter.addWidget(self.preview_canvas)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        splitter.setStretchFactor(2, 2)
        central = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(splitter)
        central.setLayout(layout)
        self.setCentralWidget(central)

    def _createGlobalOptionsPanel(self):
        self.global_options_panel = ProjectPropertiesPanel(self)
        self.addDockWidget(Qt.RightDockWidgetArea, self.global_options_panel)

    def _connectSignals(self):
        # Placeholder for future signal connections
        pass

    def new_preset(self):
        self.preset = InstrumentPreset("Untitled")
        self.sample_panel.set_samples([])
        self.mapping_form.set_mapping(None)
        self.undo_stack.clear()
        self._set_options_panel_from_preset()
        self.preview_canvas.set_preset(self.preset, os.getcwd())

    def open_preset(self):
        path, _ = QFileDialog.getOpenFileName(self, "Open .dspreset", "", "DecentSampler Preset (*.dspreset)")
        if not path:
            return
        try:
            self.preset = controller.load_preset(path)
            self.sample_panel.set_samples([m.path for m in self.preset.mappings])
            if self.preset.mappings:
                self.mapping_form.set_mapping(self.preset.mappings[0])
            else:
                self.mapping_form.set_mapping(None)
            self.undo_stack.clear()
            self._set_options_panel_from_preset()
            self.preview_canvas.set_preset(self.preset, os.path.dirname(path))
            # Optionally: push an InitialLoadCommand for undo
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to load preset:\n{e}")

    def save_preset(self):
        if not self.preset:
            QMessageBox.warning(self, "No Preset", "No preset loaded.")
            return
        # Update preset from options panel before saving
        opts = self.global_options_panel.get_options()
        self.preset.bg_image = opts["bg_image"]
        self.preset.have_attack = opts["have_attack"]
        self.preset.have_decay = opts["have_decay"]
        self.preset.have_sustain = opts["have_sustain"]
        self.preset.have_release = opts["have_release"]
        self.preset.have_tone = opts["have_tone"]
        self.preset.have_chorus = opts["have_chorus"]
        self.preset.have_reverb = opts["have_reverb"]
        self.preset.have_midicc1 = opts["have_midicc1"]
        self.preset.cut_all_by_all = opts["cut_all_by_all"]
        self.preset.silencing_mode = opts["silencing_mode"]

        path, _ = QFileDialog.getSaveFileName(self, "Save .dspreset", "", "DecentSampler Preset (*.dspreset)")
        if not path:
            return
        try:
            controller.save_preset(path, self.preset)
            self.preview_canvas.set_preset(self.preset, os.path.dirname(path))
            QMessageBox.information(self, "Saved", f"Preset saved to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to save preset:\n{e}")

    def _set_options_panel_from_preset(self):
        if not self.preset:
            return
        panel = self.global_options_panel
        panel.preset_name_edit.setText(self.preset.name)
        panel.ui_width_spin.setValue(self.preset.ui_width)
        panel.ui_height_spin.setValue(self.preset.ui_height)
        panel.bg_color_edit.setText(getattr(self.preset, "bg_color", "") or "")
        if hasattr(panel, "bg_color_btn"):
            panel.bg_color_btn.setText(getattr(self.preset, "bg_color", "") or "")
        panel.bg_edit.setText(self.preset.bg_image or "")
        # If you have additional controls (attack, decay, etc.), set them here as well
