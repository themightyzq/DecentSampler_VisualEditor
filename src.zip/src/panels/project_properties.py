from PyQt5.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QFormLayout, QLabel,
    QLineEdit, QSpinBox, QPushButton, QColorDialog, QFileDialog, QHBoxLayout
)

class ProjectPropertiesPanel(QDockWidget):
    def __init__(self, parent=None):
        super().__init__("Project Properties", parent)
        widget = QWidget()
        layout = QVBoxLayout()

        # Preset name
        self.preset_name_edit = QLineEdit()
        # UI width/height
        self.ui_width_spin = QSpinBox()
        self.ui_width_spin.setRange(100, 2000)
        self.ui_height_spin = QSpinBox()
        self.ui_height_spin.setRange(100, 2000)

        form_layout = QFormLayout()
        form_layout.addRow(QLabel("Preset Name:"), self.preset_name_edit)
        form_layout.addRow(QLabel("UI Width:"), self.ui_width_spin)
        form_layout.addRow(QLabel("UI Height:"), self.ui_height_spin)

        # Background color
        self.bg_color_btn = QPushButton("Pick Color")
        self.bg_color_btn.setToolTip("Select background color for the preset")
        self.bg_color_btn.clicked.connect(self.choose_bg_color)
        self.bg_color_edit = QLineEdit(self)
        self.bg_color_edit.setVisible(False)
        form_layout.addRow(QLabel("BG Color:"), self.bg_color_btn)

        # Background image
        self.bg_edit = QLineEdit()
        self.bg_browse_btn = QPushButton("Browse BG Image…")
        self.bg_browse_btn.setToolTip("Select background image for the preset")
        self.bg_browse_btn.clicked.connect(self.browse_bg)
        form_layout.addRow(QLabel("BG Image:"), self.bg_edit)
        form_layout.addRow("", self.bg_browse_btn)

        layout.addLayout(form_layout)

        # Background color
        from PyQt5.QtWidgets import QColorDialog, QPushButton
        bg_color_layout = QHBoxLayout()
        bg_color_layout.addWidget(QLabel("BG Color:"))
        self.bg_color_btn = QPushButton("Choose Color…")
        self.bg_color_btn.setToolTip("Select background color for the preset")
        self.bg_color_btn.clicked.connect(self.choose_bg_color)
        bg_color_layout.addWidget(self.bg_color_btn)
        # Compatibility: hidden QLineEdit for bg_color_edit
        from PyQt5.QtWidgets import QLineEdit
        self.bg_color_edit = QLineEdit(self)
        self.bg_color_edit.setVisible(False)
        bg_color_layout.addWidget(self.bg_color_edit)
        layout.addLayout(bg_color_layout)

        # Background image
        bg_img_layout = QHBoxLayout()
        bg_img_layout.addWidget(QLabel("BG Image:"))
        self.bg_edit = QLineEdit()
        bg_img_layout.addWidget(self.bg_edit)
        self.bg_browse_btn = QPushButton("Browse BG Image…")
        self.bg_browse_btn.setToolTip("Select background image for the preset")
        self.bg_browse_btn.clicked.connect(self.browse_bg)
        bg_img_layout.addWidget(self.bg_browse_btn)
        layout.addLayout(bg_img_layout)

        widget.setLayout(layout)
        self.setWidget(widget)
        # Ensure required attributes for MainWindow compatibility
        self.preset_name_edit = self.preset_name_edit
        self.ui_width_spin = self.ui_width_spin
        self.ui_height_spin = self.ui_height_spin
        self.bg_edit = self.bg_edit

    def browse_bg(self):
        file, _ = QFileDialog.getOpenFileName(self, "Select Background Image", "", "PNG Files (*.png)")
        if file:
            self.bg_edit.setText(file)
            # Live update model and preview
            mw = self.parent()
            if hasattr(mw, "preset"):
                mw.preset.bg_image = file
            if hasattr(mw, "preview_canvas") and hasattr(mw, "preset"):
                mw.preview_canvas.set_preset(mw.preset, "")

    def choose_bg_color(self):
        from PyQt5.QtWidgets import QColorDialog
        color = QColorDialog.getColor()
        if color.isValid():
            hex_color = color.name()
            self.bg_color_btn.setText(hex_color)
            self.bg_color_edit.setText(hex_color)
            mw = self.parent()
            if hasattr(mw, "preset"):
                mw.preset.bg_color = hex_color
            if hasattr(mw, "preview_canvas") and hasattr(mw, "preset"):
                mw.preview_canvas.set_preset(mw.preset, "")
